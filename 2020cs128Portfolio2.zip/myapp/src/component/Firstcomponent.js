import React from 'react';


export function Demo(){
   return <p>named component</p>
}


}
export default Firstcomponent;
 

