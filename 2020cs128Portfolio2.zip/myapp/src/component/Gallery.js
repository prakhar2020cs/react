import React from 'react'

  export function Gallery() {
  return (
<div>
    <img src=".image\abc.jpg"></img>
</div>

  );

}


 export function Profile()
{ 
  return (
    <div>
        <p>this is abesit</p>

    </div>
  );
}

