
 
import React from 'react'

export default function Gallery1() {
  return (
    <div> <img src="image/abc.jpg"></img> </div>
  )
}
