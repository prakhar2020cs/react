import React from 'react'

export default function NavLayout() {
  return (
    <div>
        <link to= "product">Product</link>
        
    </div>
  )
}
