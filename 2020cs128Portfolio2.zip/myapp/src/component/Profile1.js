import React from 'react'

export default function Profile1() {
  return (
    <div> <img src="image/logo192.png"></img> </div>
  )
}
